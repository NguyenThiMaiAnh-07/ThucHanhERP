# -*- coding: utf-8 -*-
from . import patient
from . import parent
from . import doctor
from . import pediatric_booking      
from . import appointment
from . import reception_queue
from . import receptionist    
from . import specialty
